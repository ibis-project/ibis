SELECT
  CAST("t0"."int_col" AS DateTime) AS "Cast(int_col, !timestamp)"
FROM "functional_alltypes" AS "t0"