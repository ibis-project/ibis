SELECT
  ROUND("t0"."double_col") AS "Round(double_col)"
FROM "functional_alltypes" AS "t0"