SELECT
  "t0"."bigint_col" AS "bigint_col"
FROM "functional_alltypes" AS "t0"