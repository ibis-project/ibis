SELECT
  "t0"."double_col" AS "double_col"
FROM "functional_alltypes" AS "t0"