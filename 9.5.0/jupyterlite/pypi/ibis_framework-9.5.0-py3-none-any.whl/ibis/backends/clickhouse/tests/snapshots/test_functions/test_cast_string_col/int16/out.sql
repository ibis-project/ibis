SELECT
  CAST("t0"."string_col" AS Nullable(Int16)) AS "Cast(string_col, int16)"
FROM "functional_alltypes" AS "t0"