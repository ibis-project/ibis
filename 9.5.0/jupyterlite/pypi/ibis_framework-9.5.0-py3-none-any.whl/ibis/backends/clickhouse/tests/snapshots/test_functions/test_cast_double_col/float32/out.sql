SELECT
  CAST("t0"."double_col" AS Nullable(Float32)) AS "Cast(double_col, float32)"
FROM "functional_alltypes" AS "t0"