SELECT
  ABS("t0"."double_col") AS "Abs(double_col)"
FROM "functional_alltypes" AS "t0"