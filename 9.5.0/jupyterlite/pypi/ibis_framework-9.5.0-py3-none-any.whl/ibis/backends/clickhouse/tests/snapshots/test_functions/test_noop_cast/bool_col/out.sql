SELECT
  "t0"."bool_col" AS "bool_col"
FROM "functional_alltypes" AS "t0"