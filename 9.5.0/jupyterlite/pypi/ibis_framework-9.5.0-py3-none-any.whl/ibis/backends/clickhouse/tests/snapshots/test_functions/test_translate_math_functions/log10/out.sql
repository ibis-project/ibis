SELECT
  LOG10("t0"."double_col") AS "Log10(double_col)"
FROM "functional_alltypes" AS "t0"