SELECT
  "t0"."tinyint_col" AS "tinyint_col"
FROM "functional_alltypes" AS "t0"