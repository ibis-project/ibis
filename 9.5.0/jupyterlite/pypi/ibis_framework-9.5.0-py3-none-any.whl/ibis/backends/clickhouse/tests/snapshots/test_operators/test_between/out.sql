SELECT
  "t0"."int_col" BETWEEN 0 AND 10 AS "Between(int_col, 0, 10)"
FROM "functional_alltypes" AS "t0"