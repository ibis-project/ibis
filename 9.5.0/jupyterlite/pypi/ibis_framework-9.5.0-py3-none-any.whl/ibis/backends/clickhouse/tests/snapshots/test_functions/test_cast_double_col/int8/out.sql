SELECT
  CAST("t0"."double_col" AS Nullable(Int8)) AS "Cast(double_col, int8)"
FROM "functional_alltypes" AS "t0"