SELECT
  CAST("t0"."double_col" AS Float64) AS "Cast(double_col, !float64)"
FROM "functional_alltypes" AS "t0"