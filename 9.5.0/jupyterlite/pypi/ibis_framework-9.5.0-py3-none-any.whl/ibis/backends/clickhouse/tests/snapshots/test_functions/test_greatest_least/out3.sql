SELECT
  LEAST("t0"."int_col", 10) AS "Least((int_col, 10))"
FROM "functional_alltypes" AS "t0"