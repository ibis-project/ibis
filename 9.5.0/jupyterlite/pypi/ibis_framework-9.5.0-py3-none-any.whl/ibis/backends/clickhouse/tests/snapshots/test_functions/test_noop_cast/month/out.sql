SELECT
  "t0"."month" AS "month"
FROM "functional_alltypes" AS "t0"