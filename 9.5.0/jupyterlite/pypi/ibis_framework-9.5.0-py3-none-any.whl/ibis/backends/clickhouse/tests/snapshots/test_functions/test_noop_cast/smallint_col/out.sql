SELECT
  "t0"."smallint_col" AS "smallint_col"
FROM "functional_alltypes" AS "t0"