SELECT
  NOT (
    "t0"."bool_col"
  ) AS "Not(bool_col)"
FROM "functional_alltypes" AS "t0"