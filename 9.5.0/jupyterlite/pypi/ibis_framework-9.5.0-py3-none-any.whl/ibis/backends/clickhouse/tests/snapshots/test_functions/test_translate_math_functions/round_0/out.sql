SELECT
  ROUND("t0"."double_col", 0) AS "Round(double_col, 0)"
FROM "functional_alltypes" AS "t0"