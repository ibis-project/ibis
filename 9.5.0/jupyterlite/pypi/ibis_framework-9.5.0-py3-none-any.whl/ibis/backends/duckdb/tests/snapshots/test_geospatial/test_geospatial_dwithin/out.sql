SELECT
  ST_DWITHIN("t0"."geom", "t0"."geom", 3.0) AS "tmp"
FROM "t" AS "t0"