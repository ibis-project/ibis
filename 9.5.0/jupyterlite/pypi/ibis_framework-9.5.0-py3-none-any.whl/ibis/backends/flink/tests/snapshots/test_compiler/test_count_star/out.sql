SELECT
  `t0`.`i`,
  COUNT(*) AS `CountStar(table)`
FROM `table` AS `t0`
GROUP BY
  `t0`.`i`