SELECT
  bit_or(`t0`.`int_col`) AS `BitOr_int_col`
FROM `functional_alltypes` AS `t0`