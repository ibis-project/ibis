SELECT
  st_boundingbox(`t0`.`geog`).ymax AS `tmp`
FROM `t` AS `t0`