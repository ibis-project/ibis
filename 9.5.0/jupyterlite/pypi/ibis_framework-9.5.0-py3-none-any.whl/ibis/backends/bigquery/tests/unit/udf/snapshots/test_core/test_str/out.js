function f() {
    let a = 'abc';
    return a;
}