SELECT
  SUM(`t0`.`foo`) AS `Sum_foo`
FROM `t0` AS `t0`