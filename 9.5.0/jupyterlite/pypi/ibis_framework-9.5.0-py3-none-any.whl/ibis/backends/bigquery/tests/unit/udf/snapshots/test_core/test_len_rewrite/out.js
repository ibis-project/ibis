function my_func(a) {
    return a.length;
}