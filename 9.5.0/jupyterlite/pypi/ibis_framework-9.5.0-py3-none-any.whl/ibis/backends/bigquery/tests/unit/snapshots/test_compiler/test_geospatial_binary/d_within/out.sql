SELECT
  st_dwithin(`t0`.`geog0`, `t0`.`geog1`, 5.2) AS `tmp`
FROM `t` AS `t0`