SELECT
  st_numpoints(`t0`.`geog`) AS `tmp`
FROM `t` AS `t0`