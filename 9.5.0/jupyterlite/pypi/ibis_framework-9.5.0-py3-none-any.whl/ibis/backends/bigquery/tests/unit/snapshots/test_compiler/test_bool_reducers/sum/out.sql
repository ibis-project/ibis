SELECT
  SUM(CAST(`t0`.`bool_col` AS INT64)) AS `Sum_bool_col`
FROM `functional_alltypes` AS `t0`