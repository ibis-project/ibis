SELECT
  timestamp_seconds(123456789) AS `tmp`