SELECT
  TIME_TRUNC(`t0`.`a`, MINUTE) AS `tmp`
FROM `t` AS `t0`