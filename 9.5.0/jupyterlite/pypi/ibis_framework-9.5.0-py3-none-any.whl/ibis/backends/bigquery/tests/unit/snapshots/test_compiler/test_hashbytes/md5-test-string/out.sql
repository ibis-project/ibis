SELECT
  TO_HEX(MD5('test')) AS `tmp`