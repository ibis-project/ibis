function f() {
    let a = true;
    let b = false;
    return ((!a) && (!b));
}