SELECT
  DATE_TRUNC(`t0`.`a`, DAY) AS `tmp`
FROM `t` AS `t0`