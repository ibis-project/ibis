SELECT
  timestamp_millis(-123456789) AS `tmp`