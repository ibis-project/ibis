SELECT
  sha256('test') AS `tmp`